import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.net.URL;
import javafx.fxml.FXMLLoader;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.layout.AnchorPane;
import java.util.HashMap;
import java.time.LocalDate;
import javafx.scene.control.ComboBox;
import java.util.ArrayList;
import javafx.scene.control.ChoiceBox;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.layout.HBox;

/**
 * Write a description of JavaFX class AppGUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AppGUI extends Application implements Initializable
{
    // We keep track of the count, and label displaying the count:
    private static AppGUI INSTANCE;
    
    @FXML
    private AnchorPane anchorPane;
    
    @FXML
    private Button button1;
    
    @FXML
    private Button button2;
    
    @FXML
    private Pane pane1 = new Pane();
    
    @FXML
    public DatePicker startDate;
    
    @FXML
    public DatePicker endDate;
    
    private CovidDataLoader theCovidDataLoader =  CovidDataLoader.getInstance();
    
    private DateChecker theDateChecker = DateChecker.getInstance();
    
    private Pane pane2 = new Pane();
    
    /////
    private ThirdPane pane3 = new ThirdPane();//ThirdPane.getInstance();
    
    
    
    
    private Pane pane4 = new Pane();
    
    private ArrayList<String> UniqueDates;
    
    private String alertTxt;
    
    private CovidDataPanel covidDataPanel;
    
    
    
    private HashMap<Integer,Pane> panesDisplay = new HashMap<Integer,Pane>(){{
        put(1,pane1);
        put(2,pane2);
        put(3,pane3);
        put(4,pane4);
    }};
    
    private Pane currentPane = pane1;
    private int currentPaneNum = 1;
    
    public static AppGUI getInstance() {
        System.out.println(INSTANCE);
        return INSTANCE;
    }
    
    @FXML
    private void goForward(ActionEvent event) {
        if (theDateChecker.checkButtonDisability(startDate.getValue(), endDate.getValue())) {
            return;
        }
        currentPaneNum = ((currentPaneNum) % 4) + 1;
        addtoAnchor(currentPaneNum);
        }
    
    @FXML
    private void goBack(ActionEvent event) {
        if (theDateChecker.checkButtonDisability(startDate.getValue(), endDate.getValue())) {
            return;
        }
        currentPaneNum = (currentPaneNum - 2 + 4) % 4 + 1;
        addtoAnchor(currentPaneNum);
    }
    
        public String getStartDate(){
        return startDate.getValue().toString();
    }
    
    public String getEndDate() {
        return endDate.getValue().toString();
    }
    
      public LocalDate getStartLocalDate(){
        
        return startDate.getValue();
    }
    
    public LocalDate getEndLocalDate() {
        return endDate.getValue();
    }
    
    private void addtoAnchor(int currentPaneNum) {
        //System.out.println(INSTANCE);
        anchorPane.getChildren().remove(currentPane);
        //INSTANCE = this;
        
        Pane newPane = panesDisplay.get(currentPaneNum);
        switch(currentPaneNum){
            case 1:
            
            
            
            Label welcomeLabel = new Label("Welcome. Here are the instructions below: ");
            newPane.getChildren().add(welcomeLabel);
             Label instructionsLabel = new Label("The minimum start date is 2/3/2020 and 2/9/2023");
            instructionsLabel.setLayoutY(welcomeLabel.getLayoutY() + welcomeLabel.getHeight() + 10);
            
            newPane.getChildren().add(instructionsLabel);
            /*
            newPane.setPrefWidth(pane1.getWidth());  // Set dimensions as needed
            newPane.setPrefHeight(pane1.getHeight());
    
            newPane.setLayoutX(pane1.getLayoutX());
            newPane.setLayoutY(pane1.getLayoutY());*/
    
            anchorPane.getChildren().add(newPane);
    
            currentPane = newPane;
            break;
            
            case 2:
              //newPane.getChildren().remove(paneNumLabel);
           //Label instructionsLabel = new Label("The minimum start date is 2/3/2020 and 2/9/2023");
           //newPane.getChildren().add(instructionsLabel);
           //CovidDataPanel covidDataPanel = new CovidDataPanel(anchorPane);
           //newPane.getChildren().add(covidDataPanel);
           //newPane.getChildren().remove(paneNumLabel);
           // System.out.println("Before CovidDataPanel initialization"); // Debugging statement
           // CovidDataPanel covidDataPanel = new CovidDataPanel(anchorPane);
           // covidDataPanel.initialiseUI(); // Call the method to run initialization
           // System.out.println("After CovidDataPanel initialization"); // Debugging statement
           // newPane.getChildren().add(covidDataPanel);
           //newPane.getChildren().remove(paneNumLabel);
           covidDataPanel = new CovidDataPanel(newPane);
           newPane.getChildren().add(new Label("EEEE"));
        
            
    
            anchorPane.getChildren().add(newPane);

            currentPane = newPane;
            break;
            
            case 3:
                
            //had to cast pane into borderpane to make use of borderpane functionality
            //(for adam) original pane that fucntions same as the other 3 panels, like welcome panel
            ThirdPane statPane = (ThirdPane)panesDisplay.get(currentPaneNum);
            
            statPane.loadPage();
            anchorPane.getChildren().add(statPane);
            currentPane = statPane;
            
            break;
            
            case 4:
            Pane newPane4 = panesDisplay.get(currentPaneNum);
            Label paneNumLabel4 = new Label("" + currentPaneNum);
            newPane4.getChildren().add(paneNumLabel4);
            
            anchorPane.getChildren().add(newPane4);
    
            currentPane = newPane4;
            break;
            
        }
    }
    
    
    
    // Various similar methods to generate the statistics for pane 3
    
   
   
    
    
    /**
     * The start method is the main entry point for every JavaFX application. 
     * It is called after the init() method has returned and after 
     * the system is ready for the application to begin running.
     *
     * @param  stage the primary stage for this application.
     */
    @Override
    public void start(Stage stage) throws Exception
    {
        // Create a Button or any control item
        
        URL url = getClass().getResource("mainWindow1.fxml");
        Pane root = FXMLLoader.load(url);
        
        Scene scene = new Scene(root);
        
        stage.setTitle("JavaFX Example");
        stage.setScene(scene);
        
        stage.show();
        /*
         if (INSTANCE == null) {
        INSTANCE = this;
        System.out.println(INSTANCE);
        
        }  */
           
    }
    
       
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        INSTANCE = this;
        addtoAnchor(1);
        initializePanes();
        startDate.setValue(LocalDate.of(2022, 3, 8));  
        endDate.setValue(LocalDate.of(2022, 4, 24)); 
        startDate.setEditable(false);
        endDate.setEditable(false);
        
        
    }
    
     private void initializePanes() {
        for (Pane pane : panesDisplay.values()) {
            pane.setPrefWidth(643);  // Set dimensions as needed
            pane.setPrefHeight(329);
            pane.setLayoutX(0);
            pane.setLayoutY(44);
            
            
        }
        
    }
    
}
