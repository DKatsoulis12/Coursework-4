

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import java.util.List;
import java.util.ArrayList;

/**
 * Write a description of JavaFX class SecondPane here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SecondPane extends Pane
{
    
    //Method one. Each row is a HBOX containing assigned row of hexagons. All contained in a VBXOX - > 95% likely, this method
    //Method two: Each hexagon picture can be a button and a label rendered on top of it. The label text is the one changing color
    
    //private final String MAP_IMAGE_PATH = "borough.png";
    //private ImageView mapImageVIew;
    
    private List<CovidData> covidDataList = new CovidDataLoader().load();
    
    private void initialiseUI(){
        //Load the map image
            //Adjust width, and height
        
       // Image mapImage = new Image(getClass().getResource(MAP_IMAGE_PATH));
       // mapImageView = new ImageView(mapImage);
        //mapImageView.setFitWidth(800);
       // mapImageView.setFitHeight(600);
        
        //getChildren().add(mapImageVIew)
        
        //addBoroughLabels();
        //Add the map image to the pane : getChildren() method
        
        //Add labels for each borough : use addBoroughLables() function
    }
    
    public Button addButton(String borough){
        Button btn = new Button(borough);
        //List<CovidData> covidDataList = new CovidDataLoader().load();
        
        List<CovidData> specificBoroughData = new ArrayList<>();
        for (CovidData data: covidDataList) {
            if (data.getBorough().equals(borough)) {
                specificBoroughData.add(data);
            }
        }
        int totalDeaths = getNewDeathsForBorough(specificBoroughData,AppGUI.getInstance().getStartDate(),AppGUI.getInstance().getEndDate());
        
        
        return btn;
    }
    
    
    private ArrayList<Integer> calculateBoundaries() {
        return null;
    }
    
    private void addBoroughBTN() {
        //Load the CSV data
        List<CovidData> covidDataList = new CovidDataLoader().load();
        //loop through the list, and create another list which just holds the boroughs
        //Create a hashset that takes all the unique boroughs
        
        //Loop through the hahset(borough)
            //find the object in dataset
            //int n = boroughDifferenceDeaths(borough);
            //create a new button for each borough - VBOX AND HBOX TO BE FIGURED OUT
            //btn.setText("%(borough)")
            //set x and y value
            //set the color based on n (number of new deaths)
            /*
             * if (n > 50) {
             * 
             *     btn.setTextFill(Color.RED);
               } else if (n > 40) {
                   btn.setTextFill(Color.ORANGE);
               } else if (n> 30) {
                   btn.setTextFill(Color.LIGHTGREEN);
               } else{
                   btn.setTextFill(Color.DEEPGREEN);
               }
            btn.setFont(Font.font("Calbri",FontWeight.BOLD,12));   
            
             */
        
    }
    
    private int totalBoroughsAverageDeaths(int totalDeathsTogether, int boroughNum) {
        return totalDeathsTogether/boroughNum;
    }
    
    /*private int boroughDifferenceDeaths(String borough){
        //get the startDate 
        //get the endDate 
        //int newDeaths = getNewDeathsForBorough(borough,covidDataList);
        int finalTotal = 0;
        return finalTotal; //change
    }*/
    
    private int getNewDeathsForBorough(List<CovidData> covidList, String startDate, String endDate) {
        boolean flag1 = false;
        boolean flag2 = false;
        int initialdeaths = 0;
        int finaldeaths = 0;
        
        for (CovidData data: covidList) {
            if (data.getDate().equals(startDate)) {
                flag1 = true;
                initialdeaths += data.getTotalDeaths();
            } else if (data.getDate().equals(endDate)) {
                flag2 = true;
                finaldeaths += data.getTotalDeaths();
            }
            if (flag1 && flag2) {
                return (finaldeaths - initialdeaths);
            }
        }
        return 0;
    }
    
}