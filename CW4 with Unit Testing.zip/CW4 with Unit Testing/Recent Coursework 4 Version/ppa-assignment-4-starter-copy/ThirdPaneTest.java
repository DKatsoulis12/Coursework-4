

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;

import org.mockito.*;


/**
 * The test class ThirdPaneTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ThirdPaneTest
{
    
    ThirdPane thirdPane;
    AppGUI appGUIMock;
    
    /**
     * Default constructor for test class ThirdPaneTest
     */
    public ThirdPaneTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
        thirdPane = new ThirdPane();
        appGUIMock = Mockito.mock(AppGUI.class);
    }

    // Verify method allows us to verify if the mock void method is being called or not
    // Also lets us check the number of method invocations - i.e. if this returns 0, we
    // know our mock method is not being called
    
    @Test
    public void deathsLabelDisplayed() {
        LocalDate startDate = appGUIMock.getStartLocalDate();
        LocalDate endDate = appGUIMock.getEndLocalDate();
        
        thirdPane.loadPage();
        
        ThirdPane pageLoader = Mockito.mock(ThirdPane.class);
        
        //Mockito.verify(thirdPane, Mockito.times(1)).getUpdatedDate();
        
        Mockito.verify(appGUIMock, Mockito.times(1)).getStartLocalDate();
        
        Mockito.when(appGUIMock.getStartLocalDate()).thenReturn(LocalDate.of(2022, 1, 1));
    }
    
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
        thirdPane = null;
    }
}
