import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.net.URL;
import javafx.fxml.FXMLLoader;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;
import javafx.scene.layout.AnchorPane;
import java.util.HashMap;
import java.time.LocalDate;
import javafx.scene.control.ComboBox;
import java.util.ArrayList;
import javafx.scene.control.ChoiceBox;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;

/**
 * Write a description of JavaFX class AppGUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class AppGUI extends Application implements Initializable
{
    // We keep track of the count, and label displaying the count:

    @FXML
    private AnchorPane anchorPane;
    
    @FXML
    private Button button1;
    
    @FXML
    private Button button2;
    
    @FXML
    private Pane pane1 = new Pane();
    
    private CovidDataLoader theCovidDataLoader = new CovidDataLoader();
    
    @FXML
    private DatePicker startDate;
    
    @FXML
    private DatePicker endDate;
    
    private Pane pane2 = new Pane();
    
    /////
    private BorderPane pane3 = new BorderPane();
    
    ///// for Stats Pane 3...
    
    private BorderPane statPaneBase;
    
    private int currentStatNum;
    
    private static final int MAX_STAT_PANE = 4;
    private static final int MIN_STAT_PANE = 1;    
    /////
    private static final int FONT_SIZE = 25;
    
    private Pane pane4 = new Pane();
    
    private ArrayList<String> UniqueDates;
    
    private String alertTxt;
    
    private HashMap<Integer,Pane> panesDisplay = new HashMap<Integer,Pane>(){{
        put(1,pane1);
        put(2,pane2);
        put(3,pane3);
        put(4,pane4);
    }};
    
    private Pane currentPane = pane1;
    private int currentPaneNum = 1;
    
    @FXML
    private void goForward(ActionEvent event) {
        if (!toggleButtonDisability()) {
            currentPaneNum = ((currentPaneNum) % 4) + 1;
            addtoAnchor(currentPaneNum);
        } else {
            alertSetUp();
        }
    }
    
    @FXML
    private void goBack(ActionEvent event) {
        if (!toggleButtonDisability()) {
            currentPaneNum = (currentPaneNum - 2 + 4) % 4 + 1;
            addtoAnchor(currentPaneNum);
        } else {
            alertSetUp();
        }
    }
    
    private void addtoAnchor(int currentPaneNum) {
        anchorPane.getChildren().remove(currentPane);

        switch(currentPaneNum){
            case 1:
            
            Pane newPane = panesDisplay.get(currentPaneNum);
            Label welcomeLabel = new Label("Welcome. Here are the instructions below: ");
            newPane.getChildren().add(welcomeLabel);
        
            Label instructionsLabel = new Label("For available data, the minimum start date is 2/3/2020 and the maximum end date 2/9/2023");
            instructionsLabel.setLayoutY(welcomeLabel.getLayoutY() + welcomeLabel.getHeight() + 10);
            
            newPane.getChildren().add(instructionsLabel);
            newPane.setPrefWidth(pane1.getWidth());  // Set dimensions as needed
            newPane.setPrefHeight(pane1.getHeight());
    
            newPane.setLayoutX(pane1.getLayoutX());
            newPane.setLayoutY(pane1.getLayoutY());
    
            anchorPane.getChildren().add(newPane);
    
            currentPane = newPane;
            break;
            
            case 2:
            Pane newPane2 = panesDisplay.get(currentPaneNum);
            Label paneNumLabel2 = new Label("" + currentPaneNum);
            newPane2.getChildren().add(paneNumLabel2);
            newPane2.setPrefWidth(pane1.getWidth());  // Set dimensions as needed
            newPane2.setPrefHeight(pane1.getHeight());
    
            newPane2.setLayoutX(pane1.getLayoutX());
            newPane2.setLayoutY(pane1.getLayoutY());
    
            anchorPane.getChildren().add(newPane2);
    
            currentPane = newPane2;
            break;
            
            case 3:
                
            //had to cast pane into borderpane to make use of borderpane functionality
            //(for adam) original pane that fucntions same as the other 3 panels, like welcome panel
            statPaneBase = (BorderPane)panesDisplay.get(currentPaneNum);
            
            Button leftButton = new Button("<"); 
            Button rightButton = new Button(">");
            
            leftButton.setPrefWidth(135);
            leftButton.setPrefHeight(325);
            
            rightButton.setPrefWidth(135);
            rightButton.setPrefHeight(325);
            
            //(for adam) first panel within the above stats panel to iterate between, so each of the above stats below should go 
            //into a new pane like statpane2, statpane3, now they are all sent to pane1 and are not all displayed
            
            
            Label totalDeathsLabel = generateTotalDeathsLabel();
            //Label averageCasesLabel = generateAverageCasesLabel();
            //Label averageGMR1Label = generateGMR1Label();
            //Label averageGMR2Label = generateGMR2Label();
            
            currentStatNum = 1;
            
            statPaneBase.setCenter(totalDeathsLabel);
            statPaneBase.setLeft(leftButton);
            statPaneBase.setRight(rightButton);
            
            
            leftButton.setOnAction(this::goLeftStats);
            rightButton.setOnAction(this::goRightStats);
            
            statPaneBase.setPrefWidth(pane1.getWidth());  // Set dimensions as needed
            statPaneBase.setPrefHeight(pane1.getHeight());
    
            statPaneBase.setLayoutX(pane1.getLayoutX());
            statPaneBase.setLayoutY(pane1.getLayoutY());
            anchorPane.getChildren().add(statPaneBase);
            currentPane = statPaneBase;
            
            break;
            
            case 4:
            Pane newPane4 = panesDisplay.get(currentPaneNum);
            Label paneNumLabel4 = new Label("" + currentPaneNum);
            newPane4.getChildren().add(paneNumLabel4);
            newPane4.setPrefWidth(pane1.getWidth());  // Set dimensions as needed
            newPane4.setPrefHeight(pane1.getHeight());
    
            newPane4.setLayoutX(pane1.getLayoutX());
            newPane4.setLayoutY(pane1.getLayoutY());
    
            anchorPane.getChildren().add(newPane4);
    
            currentPane = newPane4;
            break;
            
        }
    }
    
    
    private void goLeftStats (ActionEvent event) {
        if (!toggleButtonDisability()) {
            if (currentStatNum <= MIN_STAT_PANE) {
                currentStatNum = MAX_STAT_PANE;
            }
            else {
                currentStatNum--;
            }
        
            Label newLabel;
            //newLabel.setPrefWidth(pane1.getWidth() - 135 - 135);
            
            // generate and update appropriate stats label
            if (currentStatNum == 1) {
                newLabel = generateTotalDeathsLabel();
                statPaneBase.setCenter(newLabel);
            }
            else if (currentStatNum == 2) {
                newLabel = generateAverageCasesLabel();
                statPaneBase.setCenter(newLabel);
            }
            else if (currentStatNum == 3) {
                newLabel = generateGMR1Label();
                statPaneBase.setCenter(newLabel);
                //newLabel.setStyle("-text-align: center;");
                //newLabel.setWrapText(true);
            }
            else if (currentStatNum == 4) {
                newLabel = generateGMR2Label();
                statPaneBase.setCenter(newLabel);
                //newLabel.setWrapText(true);
                //newLabel.setStyle("-fx-alignment: center;");
            }
            
            /*
            newLabel.setPrefWidth(pane1.getWidth() - 135 - 135);
            newLabel.setPrefHeight(pane1.getHeight());
            newLabel.setStyle("-fx-alignment: center;");
            */
        }
        else {
            alertSetUp();
        }
    }
    
    private void goRightStats (ActionEvent event) {
        if (!toggleButtonDisability()) {
            if (currentStatNum >= MAX_STAT_PANE) {
                currentStatNum = MIN_STAT_PANE;
            }
            else {
                currentStatNum++;
            }
        
            Label newLabel;
            
            // generate and update appropriate stats label
            if (currentStatNum == 1) {
                newLabel = generateTotalDeathsLabel();
                statPaneBase.setCenter(newLabel);
            }
            else if (currentStatNum == 2) {
                newLabel = generateAverageCasesLabel();
                statPaneBase.setCenter(newLabel);
            }
            else if (currentStatNum == 3) {
                newLabel = generateGMR1Label();
                statPaneBase.setCenter(newLabel);
                //newLabel.setWrapText(true);
                //newLabel.setStyle("-fx-alignment: center;");
            }
            else if (currentStatNum == 4) {
                newLabel = generateGMR2Label();
                statPaneBase.setCenter(newLabel);
                //newLabel.setWrapText(true);
                //newLabel.setStyle("-fx-alignment: center;");
            }
        }
        else {
            alertSetUp();
        }
    }
    

    // Various similar methods to generate the statistics for pane 3
    
    private Label generateTotalDeathsLabel () {
        Label totalDeathsLabel;
        
        Integer totalDeaths = theCovidDataLoader.loadTotalDeath(startDate.getValue(), endDate.getValue());
        if (totalDeaths == null){
            //since the database includes dates where not all the columns are filled, all of these cases are addressed similar to below
            totalDeathsLabel = new Label("data base does not fully cover selected period\nplease choose after 3/9/2020 for total deaths");
            totalDeathsLabel.setFont(new Font(FONT_SIZE));
            statPaneBase.setCenter(totalDeathsLabel); // was statPane1
        }
        else{
            totalDeathsLabel = new Label("Total Deaths: " + totalDeaths);
            totalDeathsLabel.setFont(new Font(FONT_SIZE));
            statPaneBase.setCenter(totalDeathsLabel);
        }
        
        return totalDeathsLabel;
    }
    
    private Label generateAverageCasesLabel () {
        Label averageCasesLabel;
        
        Long averageCases = theCovidDataLoader.loadAverageCases(startDate.getValue(), endDate.getValue());
        if(averageCases == null){
            averageCasesLabel = new Label("data base does not fully cover selected period\nplease choose before 2/8/2023 for average cases");
            averageCasesLabel.setFont(new Font(FONT_SIZE));
            averageCasesLabel.setWrapText(true);
            statPaneBase.setCenter(averageCasesLabel); // was statPane2
        }
        else{
            averageCasesLabel = new Label("Average Cases per Day: " + averageCases);
            averageCasesLabel.setFont(new Font(FONT_SIZE));
            statPaneBase.setCenter(averageCasesLabel);
        }
        
        return averageCasesLabel;
    }
    
    private Label generateGMR1Label () {
        Label averageGMR1Label;
        
        Long GMR1 = theCovidDataLoader.loadAverageGMR(startDate.getValue(), endDate.getValue(), 2);   
        if(GMR1 == null){
            averageGMR1Label = new Label("data base does not fully cover selected period\nplease choose between 2/15/2020 and 10/15/2022 for GMR");
            averageGMR1Label.setFont(new Font(FONT_SIZE));
            averageGMR1Label.setWrapText(true);
            statPaneBase.setCenter(averageGMR1Label); // was statPane3
        }
        else{
            averageGMR1Label = new Label("Average Retail and Recreation \nPercentage Change: " + GMR1 + "%");
            averageGMR1Label.setFont(new Font(FONT_SIZE));
            statPaneBase.setCenter(averageGMR1Label);
        }
        
        return averageGMR1Label;
    }
    
    private Label generateGMR2Label () {
        Label averageGMR2Label;
        
        Long GMR2 = theCovidDataLoader.loadAverageGMR(startDate.getValue(), endDate.getValue(), 5);
        if (GMR2 == null){
            averageGMR2Label = new Label("Database does not fully cover selected period.\nPlease choose between ---");
            averageGMR2Label.setFont(new Font(FONT_SIZE));
            statPaneBase.setCenter(averageGMR2Label);
        }
        else{
            averageGMR2Label = new Label("Average Transit Stations \nPercentage Change: " + GMR2 + "%");
            averageGMR2Label.setFont(new Font(FONT_SIZE));
            statPaneBase.setCenter(averageGMR2Label);
        }
        
        return averageGMR2Label;
    }
    
    
    
    private void setAlertText(boolean startLarger, boolean invalidRange) {
        if (startLarger) {
            alertTxt = "Start Date is bigger than the End Date";
        } else if (invalidRange) {
            alertTxt = "Data not available for all these days. Not a valid range";
        } else {
            alertTxt = "";
        }
    }
    
    private void alertSetUp() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Invalid Date Selection");
        alert.setHeaderText(null);
        alert.setContentText(alertTxt);
            
        alert.showAndWait();
    }
    
    /**
     * The start method is the main entry point for every JavaFX application. 
     * It is called after the init() method has returned and after 
     * the system is ready for the application to begin running.
     *
     * @param  stage the primary stage for this application.
     */
    @Override
    public void start(Stage stage) throws Exception
    {
        // Create a Button or any control item
        URL url = getClass().getResource("mainWindow1.fxml");
        Pane root = FXMLLoader.load(url);
        
        Scene scene = new Scene(root);
        
        stage.setTitle("JavaFX Example");
        stage.setScene(scene);
        
        stage.show();
        
    }
    
    private boolean toggleButtonDisability()
    {
        LocalDate startDateValue = startDate.getValue();
        LocalDate endDateValue = endDate.getValue();
        String startDateString = startDateValue.toString();
        String endDateString = endDateValue.toString();
        boolean flag1 =  startDate.getValue().isAfter(endDate.getValue());
        boolean flag2 = !(UniqueDates.contains(startDateString) && UniqueDates.contains(endDateString));
        if (flag1 || flag2) {
            setAlertText(flag1, flag2);
            return true;
        } else {
            return false;
        }
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UniqueDates = theCovidDataLoader.loadUniqueDates();
        addtoAnchor(1);
        startDate.setValue(LocalDate.of(2022, 3, 8));  
        endDate.setValue(LocalDate.of(2022, 4, 24)); 
        
        startDate.setEditable(false);
        endDate.setEditable(false);
    }
}
