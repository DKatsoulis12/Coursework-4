import javafx.event.ActionEvent;

/**
 * Write a description of interface AppPane here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface AppPane
{
    /**
     * An example of a method header - replace this comment with your own
     *
     * @param  y a sample parameter for a method
     * @return   the result produced by sampleMethod
     */
    public abstract void updatePane();
    
}
