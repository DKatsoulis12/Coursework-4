import javafx.scene.layout.Pane;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import java.time.LocalDate;
import javafx.scene.text.Font;
import javafx.event.ActionEvent;

/**
 * Write a description of class ThirdPane here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ThirdPane extends BorderPane
{
    private CovidDataLoader theCovidDataLoader =  CovidDataLoader.getInstance();
    private DateChecker theDataChecker = DateChecker.getInstance();
    private int currentStatNum;
 
    private static final int FONT_SIZE = 25;
    
    private static ThirdPane uniqueInstance;
    
    
    private static final int MAX_STAT_PANE = 4;
    private static final int MIN_STAT_PANE = 1;    
    
    private Button leftButton = new Button("<"); 
    private Button rightButton = new Button(">");
    
         public static ThirdPane getInstance() {
         if (uniqueInstance == null) {
          uniqueInstance = new ThirdPane();
         } 
         return uniqueInstance;
    }
     
    /**
     * Constructor for objects of class ThirdPane
     */
    public ThirdPane()
    {
            
            leftButton.setPrefWidth(135);
            leftButton.setPrefHeight(325);
            
            rightButton.setPrefWidth(135);
            rightButton.setPrefHeight(325);
            
            //(for adam) first panel within the above stats panel to iterate between, so each of the above stats below should go 
            //into a new pane like statpane2, statpane3, now they are all sent to pane1 and are not all displayed
            
            
           
            //Label averageCasesLabel = generateAverageCasesLabel();
            //Label averageGMR1Label = generateGMR1Label();
            //Label averageGMR2Label = generateGMR2Label();
            
            
            
            
            setLeft(leftButton);
            setRight(rightButton);
            
            
            
            
    }
    
    public void setSize(double width, double height, double layoutX, double layoutY){
        
            
            
            
            
            setPrefWidth(width);  // Set dimensions as needed
            setPrefHeight(height);
    
            setLayoutX(layoutX);
            setLayoutY(layoutY);
    }
    public void loadPage(LocalDate startDate, LocalDate endDate){
        currentStatNum = 0;
        Label totalDeathsLabel = generateTotalDeathsLabel(startDate, endDate);
        setCenter(totalDeathsLabel);
        leftButton.setOnAction(event -> goLeftStats(startDate, endDate, event));
        rightButton.setOnAction(event -> goRightStats(startDate, endDate, event));
    }
    
    private Label generateTotalDeathsLabel (LocalDate startDate, LocalDate endDate) {
        Label totalDeathsLabel;
        
        Integer totalDeaths = theCovidDataLoader.loadTotalDeath(startDate, endDate);
        if (totalDeaths == null){
            //since the database includes dates where not all the columns are filled, all of these cases are addressed similar to below
            totalDeathsLabel = new Label("data base does not fully cover selected period\nplease choose after 3/9/2020 for total deaths");
            totalDeathsLabel.setFont(new Font(FONT_SIZE));
            setCenter(totalDeathsLabel); // was statPane1
        }
        else{
            totalDeathsLabel = new Label("Total Deaths: " + totalDeaths);
            totalDeathsLabel.setFont(new Font(FONT_SIZE));
            setCenter(totalDeathsLabel);
        }
        
        return totalDeathsLabel;
    }
    
     private Label generateAverageCasesLabel (LocalDate startDate, LocalDate endDate) {
        Label averageCasesLabel;
        
        Long averageCases = theCovidDataLoader.loadAverageCases(startDate, endDate);
        if(averageCases == null){
            averageCasesLabel = new Label("data base does not fully cover selected period\nplease choose before 2/8/2023 for average cases");
            averageCasesLabel.setFont(new Font(FONT_SIZE));
            averageCasesLabel.setWrapText(true);
            setCenter(averageCasesLabel); // was statPane2
        }
        else{
            averageCasesLabel = new Label("Average Cases per Day: " + averageCases);
            averageCasesLabel.setFont(new Font(FONT_SIZE));
            setCenter(averageCasesLabel);
        }
        
        return averageCasesLabel;
    }
    
    private Label generateGMR1Label (LocalDate startDate, LocalDate endDate) {
        Label averageGMR1Label;
        
        Long GMR1 = theCovidDataLoader.loadAverageGMR(startDate, endDate, 2);   
        if(GMR1 == null){
            averageGMR1Label = new Label("data base does not fully cover selected period\nplease choose between 2/15/2020 and 10/15/2022 for GMR");
            averageGMR1Label.setFont(new Font(FONT_SIZE));
            averageGMR1Label.setWrapText(true);
            setCenter(averageGMR1Label); // was statPane3
        }
        else{
            averageGMR1Label = new Label("Average Retail and Recreation \nPercentage Change: " + GMR1 + "%");
            averageGMR1Label.setFont(new Font(FONT_SIZE));
            setCenter(averageGMR1Label);
        }
        
        return averageGMR1Label;
    }
    
    private Label generateGMR2Label (LocalDate startDate, LocalDate endDate) {
        Label averageGMR2Label;
        
        Long GMR2 = theCovidDataLoader.loadAverageGMR(startDate, endDate, 5);
        if (GMR2 == null){
            averageGMR2Label = new Label("Database does not fully cover selected period.\nPlease choose between ---");
            averageGMR2Label.setFont(new Font(FONT_SIZE));
            setCenter(averageGMR2Label);
        }
        else{
            averageGMR2Label = new Label("Average Transit Stations \nPercentage Change: " + GMR2 + "%");
            averageGMR2Label.setFont(new Font(FONT_SIZE));
            setCenter(averageGMR2Label);
        }
        
        return averageGMR2Label;
    }
    
    private void goLeftStats (LocalDate startDate, LocalDate endDate, ActionEvent event) {
        if (theDataChecker.checkButtonDisability(startDate, endDate)) {
            return;
        }
        
            if (currentStatNum <= MIN_STAT_PANE) {
                currentStatNum = MAX_STAT_PANE;
            }
            else {
                currentStatNum--;
            }
        
            Label newLabel;
            //newLabel.setPrefWidth(pane1.getWidth() - 135 - 135);
            
            // generate and update appropriate stats label
            if (currentStatNum == 1) {
                newLabel = generateTotalDeathsLabel(startDate, endDate);
                setCenter(newLabel);
            }
            else if (currentStatNum == 2) {
                newLabel = generateAverageCasesLabel(startDate, endDate);
                setCenter(newLabel);
            }
            else if (currentStatNum == 3) {
                newLabel = generateGMR1Label(startDate, endDate);
                setCenter(newLabel);
                //newLabel.setStyle("-text-align: center;");
                //newLabel.setWrapText(true);
            }
            else if (currentStatNum == 4) {
                newLabel = generateGMR2Label(startDate, endDate);
                setCenter(newLabel);
                //newLabel.setWrapText(true);
                //newLabel.setStyle("-fx-alignment: center;");
            }
            
            /*
            newLabel.setPrefWidth(pane1.getWidth() - 135 - 135);
            newLabel.setPrefHeight(pane1.getHeight());
            newLabel.setStyle("-fx-alignment: center;");
            */
        
    }
    
    private void goRightStats (LocalDate startDate, LocalDate endDate, ActionEvent event) {
        if (theDataChecker.checkButtonDisability(startDate, endDate)) {
            return;
        }
        
            if (currentStatNum >= MAX_STAT_PANE) {
                currentStatNum = MIN_STAT_PANE;
            }
            else {
                currentStatNum++;
            }
        
            Label newLabel;
            
            // generate and update appropriate stats label
            if (currentStatNum == 1) {
                newLabel = generateTotalDeathsLabel(startDate, endDate);
                setCenter(newLabel);
            }
            else if (currentStatNum == 2) {
                newLabel = generateAverageCasesLabel(startDate, endDate);
                setCenter(newLabel);
            }
            else if (currentStatNum == 3) {
                newLabel = generateGMR1Label(startDate, endDate);
                setCenter(newLabel);
                //newLabel.setWrapText(true);
                //newLabel.setStyle("-fx-alignment: center;");
            }
            else if (currentStatNum == 4) {
                newLabel = generateGMR2Label(startDate, endDate);
                setCenter(newLabel);
                //newLabel.setWrapText(true);
                //newLabel.setStyle("-fx-alignment: center;");
            }
        }
        
    
}
